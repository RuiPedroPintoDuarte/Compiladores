#!/bin/bash

flex mycc.l && yacc -d mycc.y -v && gcc lex.yy.c y.tab.c -o mycc && ./mycc < input.txt
